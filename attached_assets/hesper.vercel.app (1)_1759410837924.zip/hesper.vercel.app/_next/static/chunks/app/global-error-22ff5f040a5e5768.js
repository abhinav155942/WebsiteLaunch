(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4219], {
        153: (e, r, n) => {
            "use strict";
            n.d(r, {
                default: () => a
            });
            var t = n(5155),
                s = n(2115);

            function a(e) {
                let {
                    error: r,
                    reset: n
                } = e, a = (0, s.useRef)(""), o = (0, s.useRef)();
                return ((0, s.useEffect)(() => {
                    if (window.parent === window) return;
                    let e = e => window.parent.postMessage(e, "*"),
                        r = r => {
                            var n;
                            return e({
                                type: "ERROR_CAPTURED",
                                error: {
                                    message: r.message,
                                    stack: null == (n = r.error) ? void 0 : n.stack,
                                    filename: r.filename,
                                    lineno: r.lineno,
                                    colno: r.colno,
                                    source: "window.onerror"
                                },
                                timestamp: Date.now()
                            })
                        },
                        n = r => {
                            var n, t, s;
                            return e({
                                type: "ERROR_CAPTURED",
                                error: {
                                    message: null != (s = null == (n = r.reason) ? void 0 : n.message) ? s : String(r.reason),
                                    stack: null == (t = r.reason) ? void 0 : t.stack,
                                    source: "unhandledrejection"
                                },
                                timestamp: Date.now()
                            })
                        };
                    return window.addEventListener("error", r), window.addEventListener("unhandledrejection", n), o.current = setInterval(() => {
                        var r, n, t;
                        let s = document.querySelector("[data-nextjs-dialog-overlay]"),
                            o = null != (r = null == s ? void 0 : s.querySelector("h1, h2, .error-message, [data-nextjs-dialog-body]")) ? r : null,
                            l = null != (t = null != (n = null == o ? void 0 : o.textContent) ? n : null == o ? void 0 : o.innerHTML) ? t : "";
                        l && l !== a.current && (a.current = l, e({
                            type: "ERROR_CAPTURED",
                            error: {
                                message: l,
                                source: "nextjs-dev-overlay"
                            },
                            timestamp: Date.now()
                        }))
                    }, 1e3), () => {
                        window.removeEventListener("error", r), window.removeEventListener("unhandledrejection", n), o.current && clearInterval(o.current)
                    }
                }, []), (0, s.useEffect)(() => {
                    r && window.parent.postMessage({
                        type: "global-error-reset",
                        error: {
                            message: r.message,
                            stack: r.stack,
                            digest: r.digest,
                            name: r.name
                        },
                        timestamp: Date.now(),
                        userAgent: navigator.userAgent
                    }, "*")
                }, [r]), r) ? (0, t.jsx)("html", {
                    children: (0, t.jsx)("body", {
                        className: "min-h-screen bg-background text-foreground flex items-center justify-center p-4",
                        children: (0, t.jsxs)("div", {
                            className: "max-w-md w-full text-center space-y-6",
                            children: [(0, t.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, t.jsx)("h1", {
                                    className: "text-2xl font-bold text-destructive",
                                    children: "Something went wrong!"
                                }), (0, t.jsx)("p", {
                                    className: "text-muted-foreground",
                                    children: "An unexpected error occurred. Please try again fixing with Orchids"
                                })]
                            }), (0, t.jsx)("div", {
                                className: "space-y-2",
                                children: !1
                            })]
                        })
                    })
                }) : null
            }
        },
        194: (e, r, n) => {
            Promise.resolve().then(n.bind(n, 8385))
        },
        8385: (e, r, n) => {
            "use strict";
            n.r(r), n.d(r, {
                default: () => t
            });
            let t = n(153).default
        }
    },
    e => {
        var r = r => e(e.s = r);
        e.O(0, [8441, 1684, 7358], () => r(194)), _N_E = e.O()
    }
]);