"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4277], {
        2596: (e, r, o) => {
            function t() {
                for (var e, r, o = 0, t = "", a = arguments.length; o < a; o++)(e = arguments[o]) && (r = function e(r) {
                    var o, t, a = "";
                    if ("string" == typeof r || "number" == typeof r) a += r;
                    else if ("object" == typeof r)
                        if (Array.isArray(r)) {
                            var n = r.length;
                            for (o = 0; o < n; o++) r[o] && (t = e(r[o])) && (a && (a += " "), a += t)
                        } else
                            for (t in r) r[t] && (a && (a += " "), a += t);
                    return a
                }(e)) && (t && (t += " "), t += r);
                return t
            }
            o.d(r, {
                $: () => t,
                A: () => a
            });
            let a = t
        },
        9688: (e, r, o) => {
            o.d(r, {
                QP: () => ed
            });
            let t = e => {
                    let r = l(e),
                        {
                            conflictingClassGroups: o,
                            conflictingClassGroupModifiers: t
                        } = e;
                    return {
                        getClassGroupId: e => {
                            let o = e.split("-");
                            return "" === o[0] && 1 !== o.length && o.shift(), a(o, r) || s(e)
                        },
                        getConflictingClassGroupIds: (e, r) => {
                            let a = o[e] || [];
                            return r && t[e] ? [...a, ...t[e]] : a
                        }
                    }
                },
                a = (e, r) => {
                    if (0 === e.length) return r.classGroupId;
                    let o = e[0],
                        t = r.nextPart.get(o),
                        n = t ? a(e.slice(1), t) : void 0;
                    if (n) return n;
                    if (0 === r.validators.length) return;
                    let s = e.join("-");
                    return r.validators.find(({
                        validator: e
                    }) => e(s)) ? .classGroupId
                },
                n = /^\[(.+)\]$/,
                s = e => {
                    if (n.test(e)) {
                        let r = n.exec(e)[1],
                            o = r ? .substring(0, r.indexOf(":"));
                        if (o) return "arbitrary.." + o
                    }
                },
                l = e => {
                    let {
                        theme: r,
                        classGroups: o
                    } = e, t = {
                        nextPart: new Map,
                        validators: []
                    };
                    for (let e in o) i(o[e], t, e, r);
                    return t
                },
                i = (e, r, o, t) => {
                    e.forEach(e => {
                        if ("string" == typeof e) {
                            ("" === e ? r : d(r, e)).classGroupId = o;
                            return
                        }
                        if ("function" == typeof e) return c(e) ? void i(e(t), r, o, t) : void r.validators.push({
                            validator: e,
                            classGroupId: o
                        });
                        Object.entries(e).forEach(([e, a]) => {
                            i(a, d(r, e), o, t)
                        })
                    })
                },
                d = (e, r) => {
                    let o = e;
                    return r.split("-").forEach(e => {
                        o.nextPart.has(e) || o.nextPart.set(e, {
                            nextPart: new Map,
                            validators: []
                        }), o = o.nextPart.get(e)
                    }), o
                },
                c = e => e.isThemeGetter,
                m = e => {
                    if (e < 1) return {
                        get: () => void 0,
                        set: () => {}
                    };
                    let r = 0,
                        o = new Map,
                        t = new Map,
                        a = (a, n) => {
                            o.set(a, n), ++r > e && (r = 0, t = o, o = new Map)
                        };
                    return {
                        get(e) {
                            let r = o.get(e);
                            return void 0 !== r ? r : void 0 !== (r = t.get(e)) ? (a(e, r), r) : void 0
                        },
                        set(e, r) {
                            o.has(e) ? o.set(e, r) : a(e, r)
                        }
                    }
                },
                p = e => {
                    let {
                        prefix: r,
                        experimentalParseClassName: o
                    } = e, t = e => {
                        let r, o = [],
                            t = 0,
                            a = 0,
                            n = 0;
                        for (let s = 0; s < e.length; s++) {
                            let l = e[s];
                            if (0 === t && 0 === a) {
                                if (":" === l) {
                                    o.push(e.slice(n, s)), n = s + 1;
                                    continue
                                }
                                if ("/" === l) {
                                    r = s;
                                    continue
                                }
                            }
                            "[" === l ? t++ : "]" === l ? t-- : "(" === l ? a++ : ")" === l && a--
                        }
                        let s = 0 === o.length ? e : e.substring(n),
                            l = u(s);
                        return {
                            modifiers: o,
                            hasImportantModifier: l !== s,
                            baseClassName: l,
                            maybePostfixModifierPosition: r && r > n ? r - n : void 0
                        }
                    };
                    if (r) {
                        let e = r + ":",
                            o = t;
                        t = r => r.startsWith(e) ? o(r.substring(e.length)) : {
                            isExternal: !0,
                            modifiers: [],
                            hasImportantModifier: !1,
                            baseClassName: r,
                            maybePostfixModifierPosition: void 0
                        }
                    }
                    if (o) {
                        let e = t;
                        t = r => o({
                            className: r,
                            parseClassName: e
                        })
                    }
                    return t
                },
                u = e => e.endsWith("!") ? e.substring(0, e.length - 1) : e.startsWith("!") ? e.substring(1) : e,
                b = e => {
                    let r = Object.fromEntries(e.orderSensitiveModifiers.map(e => [e, !0]));
                    return e => {
                        if (e.length <= 1) return e;
                        let o = [],
                            t = [];
                        return e.forEach(e => {
                            "[" === e[0] || r[e] ? (o.push(...t.sort(), e), t = []) : t.push(e)
                        }), o.push(...t.sort()), o
                    }
                },
                f = e => ({
                    cache: m(e.cacheSize),
                    parseClassName: p(e),
                    sortModifiers: b(e),
                    ...t(e)
                }),
                g = /\s+/,
                h = (e, r) => {
                    let {
                        parseClassName: o,
                        getClassGroupId: t,
                        getConflictingClassGroupIds: a,
                        sortModifiers: n
                    } = r, s = [], l = e.trim().split(g), i = "";
                    for (let e = l.length - 1; e >= 0; e -= 1) {
                        let r = l[e],
                            {
                                isExternal: d,
                                modifiers: c,
                                hasImportantModifier: m,
                                baseClassName: p,
                                maybePostfixModifierPosition: u
                            } = o(r);
                        if (d) {
                            i = r + (i.length > 0 ? " " + i : i);
                            continue
                        }
                        let b = !!u,
                            f = t(b ? p.substring(0, u) : p);
                        if (!f) {
                            if (!b || !(f = t(p))) {
                                i = r + (i.length > 0 ? " " + i : i);
                                continue
                            }
                            b = !1
                        }
                        let g = n(c).join(":"),
                            h = m ? g + "!" : g,
                            k = h + f;
                        if (s.includes(k)) continue;
                        s.push(k);
                        let x = a(f, b);
                        for (let e = 0; e < x.length; ++e) {
                            let r = x[e];
                            s.push(h + r)
                        }
                        i = r + (i.length > 0 ? " " + i : i)
                    }
                    return i
                };

            function k() {
                let e, r, o = 0,
                    t = "";
                for (; o < arguments.length;)(e = arguments[o++]) && (r = x(e)) && (t && (t += " "), t += r);
                return t
            }
            let x = e => {
                    let r;
                    if ("string" == typeof e) return e;
                    let o = "";
                    for (let t = 0; t < e.length; t++) e[t] && (r = x(e[t])) && (o && (o += " "), o += r);
                    return o
                },
                w = e => {
                    let r = r => r[e] || [];
                    return r.isThemeGetter = !0, r
                },
                y = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
                v = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
                z = /^\d+\/\d+$/,
                j = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
                M = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
                N = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
                P = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
                C = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
                G = e => z.test(e),
                $ = e => !!e && !Number.isNaN(Number(e)),
                E = e => !!e && Number.isInteger(Number(e)),
                I = e => e.endsWith("%") && $(e.slice(0, -1)),
                S = e => j.test(e),
                _ = () => !0,
                W = e => M.test(e) && !N.test(e),
                A = () => !1,
                O = e => P.test(e),
                T = e => C.test(e),
                q = e => !B(e) && !L(e),
                Q = e => ee(e, ea, A),
                B = e => y.test(e),
                D = e => ee(e, en, W),
                F = e => ee(e, es, $),
                H = e => ee(e, eo, A),
                J = e => ee(e, et, T),
                K = e => ee(e, ei, O),
                L = e => v.test(e),
                R = e => er(e, en),
                U = e => er(e, el),
                V = e => er(e, eo),
                X = e => er(e, ea),
                Y = e => er(e, et),
                Z = e => er(e, ei, !0),
                ee = (e, r, o) => {
                    let t = y.exec(e);
                    return !!t && (t[1] ? r(t[1]) : o(t[2]))
                },
                er = (e, r, o = !1) => {
                    let t = v.exec(e);
                    return !!t && (t[1] ? r(t[1]) : o)
                },
                eo = e => "position" === e || "percentage" === e,
                et = e => "image" === e || "url" === e,
                ea = e => "length" === e || "size" === e || "bg-size" === e,
                en = e => "length" === e,
                es = e => "number" === e,
                el = e => "family-name" === e,
                ei = e => "shadow" === e;
            Symbol.toStringTag;
            let ed = function(e, ...r) {
                let o, t, a, n = function(l) {
                    return t = (o = f(r.reduce((e, r) => r(e), e()))).cache.get, a = o.cache.set, n = s, s(l)
                };

                function s(e) {
                    let r = t(e);
                    if (r) return r;
                    let n = h(e, o);
                    return a(e, n), n
                }
                return function() {
                    return n(k.apply(null, arguments))
                }
            }(() => {
                let e = w("color"),
                    r = w("font"),
                    o = w("text"),
                    t = w("font-weight"),
                    a = w("tracking"),
                    n = w("leading"),
                    s = w("breakpoint"),
                    l = w("container"),
                    i = w("spacing"),
                    d = w("radius"),
                    c = w("shadow"),
                    m = w("inset-shadow"),
                    p = w("text-shadow"),
                    u = w("drop-shadow"),
                    b = w("blur"),
                    f = w("perspective"),
                    g = w("aspect"),
                    h = w("ease"),
                    k = w("animate"),
                    x = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
                    y = () => ["center", "top", "bottom", "left", "right", "top-left", "left-top", "top-right", "right-top", "bottom-right", "right-bottom", "bottom-left", "left-bottom"],
                    v = () => [...y(), L, B],
                    z = () => ["auto", "hidden", "clip", "visible", "scroll"],
                    j = () => ["auto", "contain", "none"],
                    M = () => [L, B, i],
                    N = () => [G, "full", "auto", ...M()],
                    P = () => [E, "none", "subgrid", L, B],
                    C = () => ["auto", {
                        span: ["full", E, L, B]
                    }, E, L, B],
                    W = () => [E, "auto", L, B],
                    A = () => ["auto", "min", "max", "fr", L, B],
                    O = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"],
                    T = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"],
                    ee = () => ["auto", ...M()],
                    er = () => [G, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...M()],
                    eo = () => [e, L, B],
                    et = () => [...y(), V, H, {
                        position: [L, B]
                    }],
                    ea = () => ["no-repeat", {
                        repeat: ["", "x", "y", "space", "round"]
                    }],
                    en = () => ["auto", "cover", "contain", X, Q, {
                        size: [L, B]
                    }],
                    es = () => [I, R, D],
                    el = () => ["", "none", "full", d, L, B],
                    ei = () => ["", $, R, D],
                    ed = () => ["solid", "dashed", "dotted", "double"],
                    ec = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"],
                    em = () => [$, I, V, H],
                    ep = () => ["", "none", b, L, B],
                    eu = () => ["none", $, L, B],
                    eb = () => ["none", $, L, B],
                    ef = () => [$, L, B],
                    eg = () => [G, "full", ...M()];
                return {
                    cacheSize: 500,
                    theme: {
                        animate: ["spin", "ping", "pulse", "bounce"],
                        aspect: ["video"],
                        blur: [S],
                        breakpoint: [S],
                        color: [_],
                        container: [S],
                        "drop-shadow": [S],
                        ease: ["in", "out", "in-out"],
                        font: [q],
                        "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
                        "inset-shadow": [S],
                        leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
                        perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
                        radius: [S],
                        shadow: [S],
                        spacing: ["px", $],
                        text: [S],
                        "text-shadow": [S],
                        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
                    },
                    classGroups: {
                        aspect: [{
                            aspect: ["auto", "square", G, B, L, g]
                        }],
                        container: ["container"],
                        columns: [{
                            columns: [$, B, L, l]
                        }],
                        "break-after": [{
                            "break-after": x()
                        }],
                        "break-before": [{
                            "break-before": x()
                        }],
                        "break-inside": [{
                            "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                        }],
                        "box-decoration": [{
                            "box-decoration": ["slice", "clone"]
                        }],
                        box: [{
                            box: ["border", "content"]
                        }],
                        display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                        sr: ["sr-only", "not-sr-only"],
                        float: [{
                            float: ["right", "left", "none", "start", "end"]
                        }],
                        clear: [{
                            clear: ["left", "right", "both", "none", "start", "end"]
                        }],
                        isolation: ["isolate", "isolation-auto"],
                        "object-fit": [{
                            object: ["contain", "cover", "fill", "none", "scale-down"]
                        }],
                        "object-position": [{
                            object: v()
                        }],
                        overflow: [{
                            overflow: z()
                        }],
                        "overflow-x": [{
                            "overflow-x": z()
                        }],
                        "overflow-y": [{
                            "overflow-y": z()
                        }],
                        overscroll: [{
                            overscroll: j()
                        }],
                        "overscroll-x": [{
                            "overscroll-x": j()
                        }],
                        "overscroll-y": [{
                            "overscroll-y": j()
                        }],
                        position: ["static", "fixed", "absolute", "relative", "sticky"],
                        inset: [{
                            inset: N()
                        }],
                        "inset-x": [{
                            "inset-x": N()
                        }],
                        "inset-y": [{
                            "inset-y": N()
                        }],
                        start: [{
                            start: N()
                        }],
                        end: [{
                            end: N()
                        }],
                        top: [{
                            top: N()
                        }],
                        right: [{
                            right: N()
                        }],
                        bottom: [{
                            bottom: N()
                        }],
                        left: [{
                            left: N()
                        }],
                        visibility: ["visible", "invisible", "collapse"],
                        z: [{
                            z: [E, "auto", L, B]
                        }],
                        basis: [{
                            basis: [G, "full", "auto", l, ...M()]
                        }],
                        "flex-direction": [{
                            flex: ["row", "row-reverse", "col", "col-reverse"]
                        }],
                        "flex-wrap": [{
                            flex: ["nowrap", "wrap", "wrap-reverse"]
                        }],
                        flex: [{
                            flex: [$, G, "auto", "initial", "none", B]
                        }],
                        grow: [{
                            grow: ["", $, L, B]
                        }],
                        shrink: [{
                            shrink: ["", $, L, B]
                        }],
                        order: [{
                            order: [E, "first", "last", "none", L, B]
                        }],
                        "grid-cols": [{
                            "grid-cols": P()
                        }],
                        "col-start-end": [{
                            col: C()
                        }],
                        "col-start": [{
                            "col-start": W()
                        }],
                        "col-end": [{
                            "col-end": W()
                        }],
                        "grid-rows": [{
                            "grid-rows": P()
                        }],
                        "row-start-end": [{
                            row: C()
                        }],
                        "row-start": [{
                            "row-start": W()
                        }],
                        "row-end": [{
                            "row-end": W()
                        }],
                        "grid-flow": [{
                            "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                        }],
                        "auto-cols": [{
                            "auto-cols": A()
                        }],
                        "auto-rows": [{
                            "auto-rows": A()
                        }],
                        gap: [{
                            gap: M()
                        }],
                        "gap-x": [{
                            "gap-x": M()
                        }],
                        "gap-y": [{
                            "gap-y": M()
                        }],
                        "justify-content": [{
                            justify: [...O(), "normal"]
                        }],
                        "justify-items": [{
                            "justify-items": [...T(), "normal"]
                        }],
                        "justify-self": [{
                            "justify-self": ["auto", ...T()]
                        }],
                        "align-content": [{
                            content: ["normal", ...O()]
                        }],
                        "align-items": [{
                            items: [...T(), {
                                baseline: ["", "last"]
                            }]
                        }],
                        "align-self": [{
                            self: ["auto", ...T(), {
                                baseline: ["", "last"]
                            }]
                        }],
                        "place-content": [{
                            "place-content": O()
                        }],
                        "place-items": [{
                            "place-items": [...T(), "baseline"]
                        }],
                        "place-self": [{
                            "place-self": ["auto", ...T()]
                        }],
                        p: [{
                            p: M()
                        }],
                        px: [{
                            px: M()
                        }],
                        py: [{
                            py: M()
                        }],
                        ps: [{
                            ps: M()
                        }],
                        pe: [{
                            pe: M()
                        }],
                        pt: [{
                            pt: M()
                        }],
                        pr: [{
                            pr: M()
                        }],
                        pb: [{
                            pb: M()
                        }],
                        pl: [{
                            pl: M()
                        }],
                        m: [{
                            m: ee()
                        }],
                        mx: [{
                            mx: ee()
                        }],
                        my: [{
                            my: ee()
                        }],
                        ms: [{
                            ms: ee()
                        }],
                        me: [{
                            me: ee()
                        }],
                        mt: [{
                            mt: ee()
                        }],
                        mr: [{
                            mr: ee()
                        }],
                        mb: [{
                            mb: ee()
                        }],
                        ml: [{
                            ml: ee()
                        }],
                        "space-x": [{
                            "space-x": M()
                        }],
                        "space-x-reverse": ["space-x-reverse"],
                        "space-y": [{
                            "space-y": M()
                        }],
                        "space-y-reverse": ["space-y-reverse"],
                        size: [{
                            size: er()
                        }],
                        w: [{
                            w: [l, "screen", ...er()]
                        }],
                        "min-w": [{
                            "min-w": [l, "screen", "none", ...er()]
                        }],
                        "max-w": [{
                            "max-w": [l, "screen", "none", "prose", {
                                screen: [s]
                            }, ...er()]
                        }],
                        h: [{
                            h: ["screen", "lh", ...er()]
                        }],
                        "min-h": [{
                            "min-h": ["screen", "lh", "none", ...er()]
                        }],
                        "max-h": [{
                            "max-h": ["screen", "lh", ...er()]
                        }],
                        "font-size": [{
                            text: ["base", o, R, D]
                        }],
                        "font-smoothing": ["antialiased", "subpixel-antialiased"],
                        "font-style": ["italic", "not-italic"],
                        "font-weight": [{
                            font: [t, L, F]
                        }],
                        "font-stretch": [{
                            "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", I, B]
                        }],
                        "font-family": [{
                            font: [U, B, r]
                        }],
                        "fvn-normal": ["normal-nums"],
                        "fvn-ordinal": ["ordinal"],
                        "fvn-slashed-zero": ["slashed-zero"],
                        "fvn-figure": ["lining-nums", "oldstyle-nums"],
                        "fvn-spacing": ["proportional-nums", "tabular-nums"],
                        "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
                        tracking: [{
                            tracking: [a, L, B]
                        }],
                        "line-clamp": [{
                            "line-clamp": [$, "none", L, F]
                        }],
                        leading: [{
                            leading: [n, ...M()]
                        }],
                        "list-image": [{
                            "list-image": ["none", L, B]
                        }],
                        "list-style-position": [{
                            list: ["inside", "outside"]
                        }],
                        "list-style-type": [{
                            list: ["disc", "decimal", "none", L, B]
                        }],
                        "text-alignment": [{
                            text: ["left", "center", "right", "justify", "start", "end"]
                        }],
                        "placeholder-color": [{
                            placeholder: eo()
                        }],
                        "text-color": [{
                            text: eo()
                        }],
                        "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                        "text-decoration-style": [{
                            decoration: [...ed(), "wavy"]
                        }],
                        "text-decoration-thickness": [{
                            decoration: [$, "from-font", "auto", L, D]
                        }],
                        "text-decoration-color": [{
                            decoration: eo()
                        }],
                        "underline-offset": [{
                            "underline-offset": [$, "auto", L, B]
                        }],
                        "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                        "text-wrap": [{
                            text: ["wrap", "nowrap", "balance", "pretty"]
                        }],
                        indent: [{
                            indent: M()
                        }],
                        "vertical-align": [{
                            align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", L, B]
                        }],
                        whitespace: [{
                            whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                        }],
                        break: [{
                            break: ["normal", "words", "all", "keep"]
                        }],
                        wrap: [{
                            wrap: ["break-word", "anywhere", "normal"]
                        }],
                        hyphens: [{
                            hyphens: ["none", "manual", "auto"]
                        }],
                        content: [{
                            content: ["none", L, B]
                        }],
                        "bg-attachment": [{
                            bg: ["fixed", "local", "scroll"]
                        }],
                        "bg-clip": [{
                            "bg-clip": ["border", "padding", "content", "text"]
                        }],
                        "bg-origin": [{
                            "bg-origin": ["border", "padding", "content"]
                        }],
                        "bg-position": [{
                            bg: et()
                        }],
                        "bg-repeat": [{
                            bg: ea()
                        }],
                        "bg-size": [{
                            bg: en()
                        }],
                        "bg-image": [{
                            bg: ["none", {
                                linear: [{
                                    to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                                }, E, L, B],
                                radial: ["", L, B],
                                conic: [E, L, B]
                            }, Y, J]
                        }],
                        "bg-color": [{
                            bg: eo()
                        }],
                        "gradient-from-pos": [{
                            from: es()
                        }],
                        "gradient-via-pos": [{
                            via: es()
                        }],
                        "gradient-to-pos": [{
                            to: es()
                        }],
                        "gradient-from": [{
                            from: eo()
                        }],
                        "gradient-via": [{
                            via: eo()
                        }],
                        "gradient-to": [{
                            to: eo()
                        }],
                        rounded: [{
                            rounded: el()
                        }],
                        "rounded-s": [{
                            "rounded-s": el()
                        }],
                        "rounded-e": [{
                            "rounded-e": el()
                        }],
                        "rounded-t": [{
                            "rounded-t": el()
                        }],
                        "rounded-r": [{
                            "rounded-r": el()
                        }],
                        "rounded-b": [{
                            "rounded-b": el()
                        }],
                        "rounded-l": [{
                            "rounded-l": el()
                        }],
                        "rounded-ss": [{
                            "rounded-ss": el()
                        }],
                        "rounded-se": [{
                            "rounded-se": el()
                        }],
                        "rounded-ee": [{
                            "rounded-ee": el()
                        }],
                        "rounded-es": [{
                            "rounded-es": el()
                        }],
                        "rounded-tl": [{
                            "rounded-tl": el()
                        }],
                        "rounded-tr": [{
                            "rounded-tr": el()
                        }],
                        "rounded-br": [{
                            "rounded-br": el()
                        }],
                        "rounded-bl": [{
                            "rounded-bl": el()
                        }],
                        "border-w": [{
                            border: ei()
                        }],
                        "border-w-x": [{
                            "border-x": ei()
                        }],
                        "border-w-y": [{
                            "border-y": ei()
                        }],
                        "border-w-s": [{
                            "border-s": ei()
                        }],
                        "border-w-e": [{
                            "border-e": ei()
                        }],
                        "border-w-t": [{
                            "border-t": ei()
                        }],
                        "border-w-r": [{
                            "border-r": ei()
                        }],
                        "border-w-b": [{
                            "border-b": ei()
                        }],
                        "border-w-l": [{
                            "border-l": ei()
                        }],
                        "divide-x": [{
                            "divide-x": ei()
                        }],
                        "divide-x-reverse": ["divide-x-reverse"],
                        "divide-y": [{
                            "divide-y": ei()
                        }],
                        "divide-y-reverse": ["divide-y-reverse"],
                        "border-style": [{
                            border: [...ed(), "hidden", "none"]
                        }],
                        "divide-style": [{
                            divide: [...ed(), "hidden", "none"]
                        }],
                        "border-color": [{
                            border: eo()
                        }],
                        "border-color-x": [{
                            "border-x": eo()
                        }],
                        "border-color-y": [{
                            "border-y": eo()
                        }],
                        "border-color-s": [{
                            "border-s": eo()
                        }],
                        "border-color-e": [{
                            "border-e": eo()
                        }],
                        "border-color-t": [{
                            "border-t": eo()
                        }],
                        "border-color-r": [{
                            "border-r": eo()
                        }],
                        "border-color-b": [{
                            "border-b": eo()
                        }],
                        "border-color-l": [{
                            "border-l": eo()
                        }],
                        "divide-color": [{
                            divide: eo()
                        }],
                        "outline-style": [{
                            outline: [...ed(), "none", "hidden"]
                        }],
                        "outline-offset": [{
                            "outline-offset": [$, L, B]
                        }],
                        "outline-w": [{
                            outline: ["", $, R, D]
                        }],
                        "outline-color": [{
                            outline: eo()
                        }],
                        shadow: [{
                            shadow: ["", "none", c, Z, K]
                        }],
                        "shadow-color": [{
                            shadow: eo()
                        }],
                        "inset-shadow": [{
                            "inset-shadow": ["none", m, Z, K]
                        }],
                        "inset-shadow-color": [{
                            "inset-shadow": eo()
                        }],
                        "ring-w": [{
                            ring: ei()
                        }],
                        "ring-w-inset": ["ring-inset"],
                        "ring-color": [{
                            ring: eo()
                        }],
                        "ring-offset-w": [{
                            "ring-offset": [$, D]
                        }],
                        "ring-offset-color": [{
                            "ring-offset": eo()
                        }],
                        "inset-ring-w": [{
                            "inset-ring": ei()
                        }],
                        "inset-ring-color": [{
                            "inset-ring": eo()
                        }],
                        "text-shadow": [{
                            "text-shadow": ["none", p, Z, K]
                        }],
                        "text-shadow-color": [{
                            "text-shadow": eo()
                        }],
                        opacity: [{
                            opacity: [$, L, B]
                        }],
                        "mix-blend": [{
                            "mix-blend": [...ec(), "plus-darker", "plus-lighter"]
                        }],
                        "bg-blend": [{
                            "bg-blend": ec()
                        }],
                        "mask-clip": [{
                            "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
                        }, "mask-no-clip"],
                        "mask-composite": [{
                            mask: ["add", "subtract", "intersect", "exclude"]
                        }],
                        "mask-image-linear-pos": [{
                            "mask-linear": [$]
                        }],
                        "mask-image-linear-from-pos": [{
                            "mask-linear-from": em()
                        }],
                        "mask-image-linear-to-pos": [{
                            "mask-linear-to": em()
                        }],
                        "mask-image-linear-from-color": [{
                            "mask-linear-from": eo()
                        }],
                        "mask-image-linear-to-color": [{
                            "mask-linear-to": eo()
                        }],
                        "mask-image-t-from-pos": [{
                            "mask-t-from": em()
                        }],
                        "mask-image-t-to-pos": [{
                            "mask-t-to": em()
                        }],
                        "mask-image-t-from-color": [{
                            "mask-t-from": eo()
                        }],
                        "mask-image-t-to-color": [{
                            "mask-t-to": eo()
                        }],
                        "mask-image-r-from-pos": [{
                            "mask-r-from": em()
                        }],
                        "mask-image-r-to-pos": [{
                            "mask-r-to": em()
                        }],
                        "mask-image-r-from-color": [{
                            "mask-r-from": eo()
                        }],
                        "mask-image-r-to-color": [{
                            "mask-r-to": eo()
                        }],
                        "mask-image-b-from-pos": [{
                            "mask-b-from": em()
                        }],
                        "mask-image-b-to-pos": [{
                            "mask-b-to": em()
                        }],
                        "mask-image-b-from-color": [{
                            "mask-b-from": eo()
                        }],
                        "mask-image-b-to-color": [{
                            "mask-b-to": eo()
                        }],
                        "mask-image-l-from-pos": [{
                            "mask-l-from": em()
                        }],
                        "mask-image-l-to-pos": [{
                            "mask-l-to": em()
                        }],
                        "mask-image-l-from-color": [{
                            "mask-l-from": eo()
                        }],
                        "mask-image-l-to-color": [{
                            "mask-l-to": eo()
                        }],
                        "mask-image-x-from-pos": [{
                            "mask-x-from": em()
                        }],
                        "mask-image-x-to-pos": [{
                            "mask-x-to": em()
                        }],
                        "mask-image-x-from-color": [{
                            "mask-x-from": eo()
                        }],
                        "mask-image-x-to-color": [{
                            "mask-x-to": eo()
                        }],
                        "mask-image-y-from-pos": [{
                            "mask-y-from": em()
                        }],
                        "mask-image-y-to-pos": [{
                            "mask-y-to": em()
                        }],
                        "mask-image-y-from-color": [{
                            "mask-y-from": eo()
                        }],
                        "mask-image-y-to-color": [{
                            "mask-y-to": eo()
                        }],
                        "mask-image-radial": [{
                            "mask-radial": [L, B]
                        }],
                        "mask-image-radial-from-pos": [{
                            "mask-radial-from": em()
                        }],
                        "mask-image-radial-to-pos": [{
                            "mask-radial-to": em()
                        }],
                        "mask-image-radial-from-color": [{
                            "mask-radial-from": eo()
                        }],
                        "mask-image-radial-to-color": [{
                            "mask-radial-to": eo()
                        }],
                        "mask-image-radial-shape": [{
                            "mask-radial": ["circle", "ellipse"]
                        }],
                        "mask-image-radial-size": [{
                            "mask-radial": [{
                                closest: ["side", "corner"],
                                farthest: ["side", "corner"]
                            }]
                        }],
                        "mask-image-radial-pos": [{
                            "mask-radial-at": y()
                        }],
                        "mask-image-conic-pos": [{
                            "mask-conic": [$]
                        }],
                        "mask-image-conic-from-pos": [{
                            "mask-conic-from": em()
                        }],
                        "mask-image-conic-to-pos": [{
                            "mask-conic-to": em()
                        }],
                        "mask-image-conic-from-color": [{
                            "mask-conic-from": eo()
                        }],
                        "mask-image-conic-to-color": [{
                            "mask-conic-to": eo()
                        }],
                        "mask-mode": [{
                            mask: ["alpha", "luminance", "match"]
                        }],
                        "mask-origin": [{
                            "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
                        }],
                        "mask-position": [{
                            mask: et()
                        }],
                        "mask-repeat": [{
                            mask: ea()
                        }],
                        "mask-size": [{
                            mask: en()
                        }],
                        "mask-type": [{
                            "mask-type": ["alpha", "luminance"]
                        }],
                        "mask-image": [{
                            mask: ["none", L, B]
                        }],
                        filter: [{
                            filter: ["", "none", L, B]
                        }],
                        blur: [{
                            blur: ep()
                        }],
                        brightness: [{
                            brightness: [$, L, B]
                        }],
                        contrast: [{
                            contrast: [$, L, B]
                        }],
                        "drop-shadow": [{
                            "drop-shadow": ["", "none", u, Z, K]
                        }],
                        "drop-shadow-color": [{
                            "drop-shadow": eo()
                        }],
                        grayscale: [{
                            grayscale: ["", $, L, B]
                        }],
                        "hue-rotate": [{
                            "hue-rotate": [$, L, B]
                        }],
                        invert: [{
                            invert: ["", $, L, B]
                        }],
                        saturate: [{
                            saturate: [$, L, B]
                        }],
                        sepia: [{
                            sepia: ["", $, L, B]
                        }],
                        "backdrop-filter": [{
                            "backdrop-filter": ["", "none", L, B]
                        }],
                        "backdrop-blur": [{
                            "backdrop-blur": ep()
                        }],
                        "backdrop-brightness": [{
                            "backdrop-brightness": [$, L, B]
                        }],
                        "backdrop-contrast": [{
                            "backdrop-contrast": [$, L, B]
                        }],
                        "backdrop-grayscale": [{
                            "backdrop-grayscale": ["", $, L, B]
                        }],
                        "backdrop-hue-rotate": [{
                            "backdrop-hue-rotate": [$, L, B]
                        }],
                        "backdrop-invert": [{
                            "backdrop-invert": ["", $, L, B]
                        }],
                        "backdrop-opacity": [{
                            "backdrop-opacity": [$, L, B]
                        }],
                        "backdrop-saturate": [{
                            "backdrop-saturate": [$, L, B]
                        }],
                        "backdrop-sepia": [{
                            "backdrop-sepia": ["", $, L, B]
                        }],
                        "border-collapse": [{
                            border: ["collapse", "separate"]
                        }],
                        "border-spacing": [{
                            "border-spacing": M()
                        }],
                        "border-spacing-x": [{
                            "border-spacing-x": M()
                        }],
                        "border-spacing-y": [{
                            "border-spacing-y": M()
                        }],
                        "table-layout": [{
                            table: ["auto", "fixed"]
                        }],
                        caption: [{
                            caption: ["top", "bottom"]
                        }],
                        transition: [{
                            transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", L, B]
                        }],
                        "transition-behavior": [{
                            transition: ["normal", "discrete"]
                        }],
                        duration: [{
                            duration: [$, "initial", L, B]
                        }],
                        ease: [{
                            ease: ["linear", "initial", h, L, B]
                        }],
                        delay: [{
                            delay: [$, L, B]
                        }],
                        animate: [{
                            animate: ["none", k, L, B]
                        }],
                        backface: [{
                            backface: ["hidden", "visible"]
                        }],
                        perspective: [{
                            perspective: [f, L, B]
                        }],
                        "perspective-origin": [{
                            "perspective-origin": v()
                        }],
                        rotate: [{
                            rotate: eu()
                        }],
                        "rotate-x": [{
                            "rotate-x": eu()
                        }],
                        "rotate-y": [{
                            "rotate-y": eu()
                        }],
                        "rotate-z": [{
                            "rotate-z": eu()
                        }],
                        scale: [{
                            scale: eb()
                        }],
                        "scale-x": [{
                            "scale-x": eb()
                        }],
                        "scale-y": [{
                            "scale-y": eb()
                        }],
                        "scale-z": [{
                            "scale-z": eb()
                        }],
                        "scale-3d": ["scale-3d"],
                        skew: [{
                            skew: ef()
                        }],
                        "skew-x": [{
                            "skew-x": ef()
                        }],
                        "skew-y": [{
                            "skew-y": ef()
                        }],
                        transform: [{
                            transform: [L, B, "", "none", "gpu", "cpu"]
                        }],
                        "transform-origin": [{
                            origin: v()
                        }],
                        "transform-style": [{
                            transform: ["3d", "flat"]
                        }],
                        translate: [{
                            translate: eg()
                        }],
                        "translate-x": [{
                            "translate-x": eg()
                        }],
                        "translate-y": [{
                            "translate-y": eg()
                        }],
                        "translate-z": [{
                            "translate-z": eg()
                        }],
                        "translate-none": ["translate-none"],
                        accent: [{
                            accent: eo()
                        }],
                        appearance: [{
                            appearance: ["none", "auto"]
                        }],
                        "caret-color": [{
                            caret: eo()
                        }],
                        "color-scheme": [{
                            scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
                        }],
                        cursor: [{
                            cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", L, B]
                        }],
                        "field-sizing": [{
                            "field-sizing": ["fixed", "content"]
                        }],
                        "pointer-events": [{
                            "pointer-events": ["auto", "none"]
                        }],
                        resize: [{
                            resize: ["none", "", "y", "x"]
                        }],
                        "scroll-behavior": [{
                            scroll: ["auto", "smooth"]
                        }],
                        "scroll-m": [{
                            "scroll-m": M()
                        }],
                        "scroll-mx": [{
                            "scroll-mx": M()
                        }],
                        "scroll-my": [{
                            "scroll-my": M()
                        }],
                        "scroll-ms": [{
                            "scroll-ms": M()
                        }],
                        "scroll-me": [{
                            "scroll-me": M()
                        }],
                        "scroll-mt": [{
                            "scroll-mt": M()
                        }],
                        "scroll-mr": [{
                            "scroll-mr": M()
                        }],
                        "scroll-mb": [{
                            "scroll-mb": M()
                        }],
                        "scroll-ml": [{
                            "scroll-ml": M()
                        }],
                        "scroll-p": [{
                            "scroll-p": M()
                        }],
                        "scroll-px": [{
                            "scroll-px": M()
                        }],
                        "scroll-py": [{
                            "scroll-py": M()
                        }],
                        "scroll-ps": [{
                            "scroll-ps": M()
                        }],
                        "scroll-pe": [{
                            "scroll-pe": M()
                        }],
                        "scroll-pt": [{
                            "scroll-pt": M()
                        }],
                        "scroll-pr": [{
                            "scroll-pr": M()
                        }],
                        "scroll-pb": [{
                            "scroll-pb": M()
                        }],
                        "scroll-pl": [{
                            "scroll-pl": M()
                        }],
                        "snap-align": [{
                            snap: ["start", "end", "center", "align-none"]
                        }],
                        "snap-stop": [{
                            snap: ["normal", "always"]
                        }],
                        "snap-type": [{
                            snap: ["none", "x", "y", "both"]
                        }],
                        "snap-strictness": [{
                            snap: ["mandatory", "proximity"]
                        }],
                        touch: [{
                            touch: ["auto", "none", "manipulation"]
                        }],
                        "touch-x": [{
                            "touch-pan": ["x", "left", "right"]
                        }],
                        "touch-y": [{
                            "touch-pan": ["y", "up", "down"]
                        }],
                        "touch-pz": ["touch-pinch-zoom"],
                        select: [{
                            select: ["none", "text", "all", "auto"]
                        }],
                        "will-change": [{
                            "will-change": ["auto", "scroll", "contents", "transform", L, B]
                        }],
                        fill: [{
                            fill: ["none", ...eo()]
                        }],
                        "stroke-w": [{
                            stroke: [$, R, D, F]
                        }],
                        stroke: [{
                            stroke: ["none", ...eo()]
                        }],
                        "forced-color-adjust": [{
                            "forced-color-adjust": ["auto", "none"]
                        }]
                    },
                    conflictingClassGroups: {
                        overflow: ["overflow-x", "overflow-y"],
                        overscroll: ["overscroll-x", "overscroll-y"],
                        inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
                        "inset-x": ["right", "left"],
                        "inset-y": ["top", "bottom"],
                        flex: ["basis", "grow", "shrink"],
                        gap: ["gap-x", "gap-y"],
                        p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
                        px: ["pr", "pl"],
                        py: ["pt", "pb"],
                        m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
                        mx: ["mr", "ml"],
                        my: ["mt", "mb"],
                        size: ["w", "h"],
                        "font-size": ["leading"],
                        "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                        "fvn-ordinal": ["fvn-normal"],
                        "fvn-slashed-zero": ["fvn-normal"],
                        "fvn-figure": ["fvn-normal"],
                        "fvn-spacing": ["fvn-normal"],
                        "fvn-fraction": ["fvn-normal"],
                        "line-clamp": ["display", "overflow"],
                        rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                        "rounded-s": ["rounded-ss", "rounded-es"],
                        "rounded-e": ["rounded-se", "rounded-ee"],
                        "rounded-t": ["rounded-tl", "rounded-tr"],
                        "rounded-r": ["rounded-tr", "rounded-br"],
                        "rounded-b": ["rounded-br", "rounded-bl"],
                        "rounded-l": ["rounded-tl", "rounded-bl"],
                        "border-spacing": ["border-spacing-x", "border-spacing-y"],
                        "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                        "border-w-x": ["border-w-r", "border-w-l"],
                        "border-w-y": ["border-w-t", "border-w-b"],
                        "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                        "border-color-x": ["border-color-r", "border-color-l"],
                        "border-color-y": ["border-color-t", "border-color-b"],
                        translate: ["translate-x", "translate-y", "translate-none"],
                        "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
                        "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                        "scroll-mx": ["scroll-mr", "scroll-ml"],
                        "scroll-my": ["scroll-mt", "scroll-mb"],
                        "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                        "scroll-px": ["scroll-pr", "scroll-pl"],
                        "scroll-py": ["scroll-pt", "scroll-pb"],
                        touch: ["touch-x", "touch-y", "touch-pz"],
                        "touch-x": ["touch"],
                        "touch-y": ["touch"],
                        "touch-pz": ["touch"]
                    },
                    conflictingClassGroupModifiers: {
                        "font-size": ["leading"]
                    },
                    orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
                }
            })
        }
    }
]);