(() => {
    "use strict";
    var e = {},
        t = {};

    function r(o) {
        var n = t[o];
        if (void 0 !== n) return n.exports;
        var a = t[o] = {
                exports: {}
            },
            i = !0;
        try {
            e[o](a, a.exports, r), i = !1
        } finally {
            i && delete t[o]
        }
        return a.exports
    }
    r.m = e, (() => {
        var e = [];
        r.O = (t, o, n, a) => {
            if (o) {
                a = a || 0;
                for (var i = e.length; i > 0 && e[i - 1][2] > a; i--) e[i] = e[i - 1];
                e[i] = [o, n, a];
                return
            }
            for (var u = 1 / 0, i = 0; i < e.length; i++) {
                for (var [o, n, a] = e[i], l = !0, c = 0; c < o.length; c++)(!1 & a || u >= a) && Object.keys(r.O).every(e => r.O[e](o[c])) ? o.splice(c--, 1) : (l = !1, a < u && (u = a));
                if (l) {
                    e.splice(i--, 1);
                    var d = n();
                    void 0 !== d && (t = d)
                }
            }
            return t
        }
    })(), r.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return r.d(t, {
            a: t
        }), t
    }, (() => {
        var e, t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__;
        r.t = function(o, n) {
            if (1 & n && (o = this(o)), 8 & n || "object" == typeof o && o && (4 & n && o.__esModule || 16 & n && "function" == typeof o.then)) return o;
            var a = Object.create(null);
            r.r(a);
            var i = {};
            e = e || [null, t({}), t([]), t(t)];
            for (var u = 2 & n && o;
                "object" == typeof u && !~e.indexOf(u); u = t(u)) Object.getOwnPropertyNames(u).forEach(e => i[e] = () => o[e]);
            return i.default = () => o, r.d(a, i), a
        }
    })(), r.d = (e, t) => {
        for (var o in t) r.o(t, o) && !r.o(e, o) && Object.defineProperty(e, o, {
            enumerable: !0,
            get: t[o]
        })
    }, r.f = {}, r.e = e => Promise.all(Object.keys(r.f).reduce((t, o) => (r.f[o](e, t), t), [])), r.u = e => {}, r.miniCssF = e => {}, r.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), (() => {
        var e = {},
            t = "_N_E:";
        r.l = (o, n, a, i) => {
            if (e[o]) return void e[o].push(n);
            if (void 0 !== a)
                for (var u, l, c = document.getElementsByTagName("script"), d = 0; d < c.length; d++) {
                    var f = c[d];
                    if (f.getAttribute("src") == o || f.getAttribute("data-webpack") == t + a) {
                        u = f;
                        break
                    }
                }
            u || (l = !0, (u = document.createElement("script")).charset = "utf-8", u.timeout = 120, r.nc && u.setAttribute("nonce", r.nc), u.setAttribute("data-webpack", t + a), u.src = r.tu(o)), e[o] = [n];
            var s = (t, r) => {
                    u.onerror = u.onload = null, clearTimeout(p);
                    var n = e[o];
                    if (delete e[o], u.parentNode && u.parentNode.removeChild(u), n && n.forEach(e => e(r)), t) return t(r)
                },
                p = setTimeout(s.bind(null, void 0, {
                    type: "timeout",
                    target: u
                }), 12e4);
            u.onerror = s.bind(null, u.onerror), u.onload = s.bind(null, u.onload), l && document.head.appendChild(u)
        }
    })(), r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, (() => {
        var e;
        r.tt = () => (void 0 === e && (e = {
            createScriptURL: e => e
        }, "undefined" != typeof trustedTypes && trustedTypes.createPolicy && (e = trustedTypes.createPolicy("nextjs#bundler", e))), e)
    })(), r.tu = e => r.tt().createScriptURL(e), r.p = "/_next/", (() => {
        var e = {
            8068: 0,
            7690: 0
        };
        r.f.j = (t, o) => {
            var n = r.o(e, t) ? e[t] : void 0;
            if (0 !== n)
                if (n) o.push(n[2]);
                else if (/^(7690|8068)$/.test(t)) e[t] = 0;
            else {
                var a = new Promise((r, o) => n = e[t] = [r, o]);
                o.push(n[2] = a);
                var i = r.p + r.u(t),
                    u = Error();
                r.l(i, o => {
                    if (r.o(e, t) && (0 !== (n = e[t]) && (e[t] = void 0), n)) {
                        var a = o && ("load" === o.type ? "missing" : o.type),
                            i = o && o.target && o.target.src;
                        u.message = "Loading chunk " + t + " failed.\n(" + a + ": " + i + ")", u.name = "ChunkLoadError", u.type = a, u.request = i, n[1](u)
                    }
                }, "chunk-" + t, t)
            }
        }, r.O.j = t => 0 === e[t];
        var t = (t, o) => {
                var n, a, [i, u, l] = o,
                    c = 0;
                if (i.some(t => 0 !== e[t])) {
                    for (n in u) r.o(u, n) && (r.m[n] = u[n]);
                    if (l) var d = l(r)
                }
                for (t && t(o); c < i.length; c++) a = i[c], r.o(e, a) && e[a] && e[a][0](), e[a] = 0;
                return r.O(d)
            },
            o = self.webpackChunk_N_E = self.webpackChunk_N_E || [];
        o.forEach(t.bind(null, 0)), o.push = t.bind(null, o.push.bind(o))
    })(), r.nc = void 0
})();;
(function() {
    if (typeof document === "undefined" || !/(?:^|;\s)__vercel_toolbar=1(?:;|$)/.test(document.cookie)) return;
    var s = document.createElement('script');
    s.src = 'https://vercel.live/_next-live/feedback/feedback.js';
    s.setAttribute("data-explicit-opt-in", "true");
    s.setAttribute("data-cookie-opt-in", "true");
    s.setAttribute("data-deployment-id", "dpl_H2L2Kv2PrBHW5QWWQ5iLUt4tZjrA");
    ((document.head || document.documentElement).appendChild(s))
})();