"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7148], {
        1275: (e, t, n) => {
            n.d(t, {
                X: () => i
            });
            var r = n(2115),
                o = n(2712);

            function i(e) {
                let [t, n] = r.useState(void 0);
                return (0, o.N)(() => {
                    if (e) {
                        n({
                            width: e.offsetWidth,
                            height: e.offsetHeight
                        });
                        let t = new ResizeObserver(t => {
                            let r, o;
                            if (!Array.isArray(t) || !t.length) return;
                            let i = t[0];
                            if ("borderBoxSize" in i) {
                                let e = i.borderBoxSize,
                                    t = Array.isArray(e) ? e[0] : e;
                                r = t.inlineSize, o = t.blockSize
                            } else r = e.offsetWidth, o = e.offsetHeight;
                            n({
                                width: r,
                                height: o
                            })
                        });
                        return t.observe(e, {
                            box: "border-box"
                        }), () => t.unobserve(e)
                    }
                    n(void 0)
                }, [e]), t
            }
        },
        2712: (e, t, n) => {
            n.d(t, {
                N: () => o
            });
            var r = n(2115),
                o = globalThis ? .document ? r.useLayoutEffect : () => {}
        },
        5185: (e, t, n) => {
            n.d(t, {
                mK: () => o
            });
            var r = !!("undefined" != typeof window && window.document && window.document.createElement);

            function o(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (e ? .(r), !1 === n || !r.defaultPrevented) return t ? .(r)
                }
            }
        },
        5196: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(9946).A)("check", [
                ["path", {
                    d: "M20 6 9 17l-5-5",
                    key: "1gmf2c"
                }]
            ])
        },
        5845: (e, t, n) => {
            n.d(t, {
                i: () => l
            });
            var r, o = n(2115),
                i = n(2712),
                u = (r || (r = n.t(o, 2)))[" useInsertionEffect ".trim().toString()] || i.N;

            function l({
                prop: e,
                defaultProp: t,
                onChange: n = () => {},
                caller: r
            }) {
                let [i, l, a] = function({
                    defaultProp: e,
                    onChange: t
                }) {
                    let [n, r] = o.useState(e), i = o.useRef(n), l = o.useRef(t);
                    return u(() => {
                        l.current = t
                    }, [t]), o.useEffect(() => {
                        i.current !== n && (l.current ? .(n), i.current = n)
                    }, [n, i]), [n, r, l]
                }({
                    defaultProp: t,
                    onChange: n
                }), s = void 0 !== e, c = s ? e : i; {
                    let t = o.useRef(void 0 !== e);
                    o.useEffect(() => {
                        let e = t.current;
                        if (e !== s) {
                            let t = s ? "controlled" : "uncontrolled";
                            console.warn(`${r} is changing from ${e?"controlled":"uncontrolled"} to ${t}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`)
                        }
                        t.current = s
                    }, [s, r])
                }
                return [c, o.useCallback(t => {
                    if (s) {
                        let n = "function" == typeof t ? t(e) : t;
                        n !== e && a.current ? .(n)
                    } else l(t)
                }, [s, e, l, a])]
            }
            Symbol("RADIX:SYNC_STATE")
        },
        6081: (e, t, n) => {
            n.d(t, {
                A: () => u,
                q: () => i
            });
            var r = n(2115),
                o = n(5155);

            function i(e, t) {
                let n = r.createContext(t),
                    i = e => {
                        let {
                            children: t,
                            ...i
                        } = e, u = r.useMemo(() => i, Object.values(i));
                        return (0, o.jsx)(n.Provider, {
                            value: u,
                            children: t
                        })
                    };
                return i.displayName = e + "Provider", [i, function(o) {
                    let i = r.useContext(n);
                    if (i) return i;
                    if (void 0 !== t) return t;
                    throw Error(`\`${o}\` must be used within \`${e}\``)
                }]
            }

            function u(e, t = []) {
                let n = [],
                    i = () => {
                        let t = n.map(e => r.createContext(e));
                        return function(n) {
                            let o = n ? .[e] || t;
                            return r.useMemo(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: o
                                }
                            }), [n, o])
                        }
                    };
                return i.scopeName = e, [function(t, i) {
                    let u = r.createContext(i),
                        l = n.length;
                    n = [...n, i];
                    let a = t => {
                        let {
                            scope: n,
                            children: i,
                            ...a
                        } = t, s = n ? .[e] ? .[l] || u, c = r.useMemo(() => a, Object.values(a));
                        return (0, o.jsx)(s.Provider, {
                            value: c,
                            children: i
                        })
                    };
                    return a.displayName = t + "Provider", [a, function(n, o) {
                        let a = o ? .[e] ? .[l] || u,
                            s = r.useContext(a);
                        if (s) return s;
                        if (void 0 !== i) return i;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let o = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let o = n(e)[`__scope${r}`];
                                return { ...t,
                                    ...o
                                }
                            }, {});
                            return r.useMemo(() => ({
                                [`__scope${t.scopeName}`]: o
                            }), [o])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(i, ...t)]
            }
        },
        8905: (e, t, n) => {
            n.d(t, {
                C: () => u
            });
            var r = n(2115),
                o = n(6101),
                i = n(2712),
                u = e => {
                    let {
                        present: t,
                        children: n
                    } = e, u = function(e) {
                        var t, n;
                        let [o, u] = r.useState(), a = r.useRef(null), s = r.useRef(e), c = r.useRef("none"), [d, f] = (t = e ? "mounted" : "unmounted", n = {
                            mounted: {
                                UNMOUNT: "unmounted",
                                ANIMATION_OUT: "unmountSuspended"
                            },
                            unmountSuspended: {
                                MOUNT: "mounted",
                                ANIMATION_END: "unmounted"
                            },
                            unmounted: {
                                MOUNT: "mounted"
                            }
                        }, r.useReducer((e, t) => {
                            let r = n[e][t];
                            return null != r ? r : e
                        }, t));
                        return r.useEffect(() => {
                            let e = l(a.current);
                            c.current = "mounted" === d ? e : "none"
                        }, [d]), (0, i.N)(() => {
                            let t = a.current,
                                n = s.current;
                            if (n !== e) {
                                let r = c.current,
                                    o = l(t);
                                e ? f("MOUNT") : "none" === o || (null == t ? void 0 : t.display) === "none" ? f("UNMOUNT") : n && r !== o ? f("ANIMATION_OUT") : f("UNMOUNT"), s.current = e
                            }
                        }, [e, f]), (0, i.N)(() => {
                            if (o) {
                                var e;
                                let t, n = null != (e = o.ownerDocument.defaultView) ? e : window,
                                    r = e => {
                                        let r = l(a.current).includes(CSS.escape(e.animationName));
                                        if (e.target === o && r && (f("ANIMATION_END"), !s.current)) {
                                            let e = o.style.animationFillMode;
                                            o.style.animationFillMode = "forwards", t = n.setTimeout(() => {
                                                "forwards" === o.style.animationFillMode && (o.style.animationFillMode = e)
                                            })
                                        }
                                    },
                                    i = e => {
                                        e.target === o && (c.current = l(a.current))
                                    };
                                return o.addEventListener("animationstart", i), o.addEventListener("animationcancel", r), o.addEventListener("animationend", r), () => {
                                    n.clearTimeout(t), o.removeEventListener("animationstart", i), o.removeEventListener("animationcancel", r), o.removeEventListener("animationend", r)
                                }
                            }
                            f("ANIMATION_END")
                        }, [o, f]), {
                            isPresent: ["mounted", "unmountSuspended"].includes(d),
                            ref: r.useCallback(e => {
                                a.current = e ? getComputedStyle(e) : null, u(e)
                            }, [])
                        }
                    }(t), a = "function" == typeof n ? n({
                        present: u.isPresent
                    }) : r.Children.only(n), s = (0, o.s)(u.ref, function(e) {
                        var t, n;
                        let r = null == (t = Object.getOwnPropertyDescriptor(e.props, "ref")) ? void 0 : t.get,
                            o = r && "isReactWarning" in r && r.isReactWarning;
                        return o ? e.ref : (o = (r = null == (n = Object.getOwnPropertyDescriptor(e, "ref")) ? void 0 : n.get) && "isReactWarning" in r && r.isReactWarning) ? e.props.ref : e.props.ref || e.ref
                    }(a));
                    return "function" == typeof n || u.isPresent ? r.cloneElement(a, {
                        ref: s
                    }) : null
                };

            function l(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            u.displayName = "Presence"
        },
        9946: (e, t, n) => {
            n.d(t, {
                A: () => d
            });
            var r = n(2115);
            let o = e => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
                i = e => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()),
                u = e => {
                    let t = i(e);
                    return t.charAt(0).toUpperCase() + t.slice(1)
                },
                l = function() {
                    for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return t.filter((e, t, n) => !!e && "" !== e.trim() && n.indexOf(e) === t).join(" ").trim()
                },
                a = e => {
                    for (let t in e)
                        if (t.startsWith("aria-") || "role" === t || "title" === t) return !0
                };
            var s = {
                xmlns: "http://www.w3.org/2000/svg",
                width: 24,
                height: 24,
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 2,
                strokeLinecap: "round",
                strokeLinejoin: "round"
            };
            let c = (0, r.forwardRef)((e, t) => {
                    let {
                        color: n = "currentColor",
                        size: o = 24,
                        strokeWidth: i = 2,
                        absoluteStrokeWidth: u,
                        className: c = "",
                        children: d,
                        iconNode: f,
                        ...m
                    } = e;
                    return (0, r.createElement)("svg", {
                        ref: t,
                        ...s,
                        width: o,
                        height: o,
                        stroke: n,
                        strokeWidth: u ? 24 * Number(i) / Number(o) : i,
                        className: l("lucide", c),
                        ...!d && !a(m) && {
                            "aria-hidden": "true"
                        },
                        ...m
                    }, [...f.map(e => {
                        let [t, n] = e;
                        return (0, r.createElement)(t, n)
                    }), ...Array.isArray(d) ? d : [d]])
                }),
                d = (e, t) => {
                    let n = (0, r.forwardRef)((n, i) => {
                        let {
                            className: a,
                            ...s
                        } = n;
                        return (0, r.createElement)(c, {
                            ref: i,
                            iconNode: t,
                            className: l("lucide-".concat(o(u(e))), "lucide-".concat(e), a),
                            ...s
                        })
                    });
                    return n.displayName = u(e), n
                }
        }
    }
]);